# Collecte des données publiques d'une commune (INSEE, DVF Cerema, ADEME, geo.api.gouv.fr)
import json, math, statistics, urllib.request, urllib.parse, datetime
from concurrent.futures import ThreadPoolExecutor

UA = {'User-Agent': 'GuyHoquet-SaintOmer-cartes/1.0'}


def get(url, timeout=40):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf8'))


def melodi(ds, insee):
    try:
        return get(f'https://api.insee.fr/melodi/data/{ds}?GEO=COM-{insee}&maxResult=5000').get('observations', [])
    except Exception:
        return []


def v(o):
    return o['measures']['OBS_VALUE_NIVEAU'].get('value')


def seul(o, garder):
    return all(k in garder or val == '_T' for k, val in o['dimensions'].items())


def mediane(a):
    a = [x for x in a if x is not None]
    return statistics.median(a) if a else None


def chercher_commune(nom_ou_code):
    s = str(nom_ou_code).strip()
    if s.isdigit() and len(s) == 5:
        return s
    r = get('https://geo.api.gouv.fr/communes?nom=' + urllib.parse.quote(s) + '&codeDepartement=62&fields=code,nom,population&boost=population&limit=1')
    if not r:
        r = get('https://geo.api.gouv.fr/communes?nom=' + urllib.parse.quote(s) + '&fields=code,nom,population&boost=population&limit=1')
    if not r:
        raise ValueError('Commune introuvable : ' + s)
    return r[0]['code']


def contours(insee, rayon_km=4.6):
    g = get(f'https://geo.api.gouv.fr/communes/{insee}?fields=nom,code,centre,contour,population,surface')
    cx, cy = g['centre']['coordinates']
    kx, ky = 111.32 * math.cos(math.radians(cy)), 110.57
    # rayon adapté à la taille de la commune (surface en ha)
    r_c = math.sqrt(g.get('surface', 1000) / 100 / math.pi)
    R = max(2.2, min(8.0, r_c * 1.9))
    pts = []
    n = 4
    for i in range(-n, n + 1):
        for j in range(-n, n + 1):
            dx, dy = i * R / n, j * R / n
            if math.hypot(dx, dy) <= R * 1.1:
                pts.append((cy - dy / ky, cx + dx / kx))

    def code_at(p):
        try:
            return [c['code'] for c in get(f'https://geo.api.gouv.fr/communes?lat={p[0]}&lon={p[1]}&fields=code')]
        except Exception:
            return []
    with ThreadPoolExecutor(8) as ex:
        codes = set(c for l in ex.map(code_at, pts) for c in l)
    codes.add(insee)

    def fiche(c):
        try:
            return get(f'https://geo.api.gouv.fr/communes/{c}?fields=nom,code,contour')
        except Exception:
            return None
    with ThreadPoolExecutor(8) as ex:
        fiches = [f for f in ex.map(fiche, codes) if f]
    S = 200 / R
    out = []
    for f in fiches:
        geom = f['contour']
        polys = [geom['coordinates']] if geom['type'] == 'Polygon' else geom['coordinates']
        ring = max(polys, key=lambda p: len(p[0]))[0]
        P = [((x - cx) * kx * S, (cy - y) * ky * S) for x, y in ring]
        out.append({'nom': f['nom'], 'code': f['code'], 'pts': P})
    return g, out


def collecter(nom_ou_code, dvf_mutations=None):
    insee = chercher_commune(nom_ou_code)
    with ThreadPoolExecutor(8) as ex:
        f_geo = ex.submit(contours, insee)
        f_log = ex.submit(melodi, 'DS_RP_LOGEMENT_PRINC', insee)
        f_pop = ex.submit(melodi, 'DS_RP_POPULATION_PRINC', insee)
        f_pcs = ex.submit(melodi, 'DS_RP_POPULATION_COMP', insee)
        f_fil = ex.submit(melodi, 'DS_FILOSOFI_CC', insee)
        f_bpe = ex.submit(melodi, 'DS_BPE', insee)
        f_dvf = ex.submit(dvf, insee, dvf_mutations)
        f_dpe = ex.submit(dpe, insee)
    g, geo = f_geo.result()
    log, pop, pcs, fil, bpe = f_log.result(), f_pop.result(), f_pcs.result(), f_fil.result(), f_bpe.result()
    D = {'insee': insee, 'nom': g['nom'], 'population': g.get('population'), 'surface_ha': g.get('surface'), 'geo': geo}

    # logement
    ans = sorted({o['dimensions']['TIME_PERIOD'] for o in log}) or ['']
    a = ans[-1]
    def logv(an, **k):
        keep = ['GEO', 'FREQ', 'TIME_PERIOD', 'RP_MEASURE'] + list(k)
        for o in log:
            d = o['dimensions']
            if d.get('TIME_PERIOD') == an and d.get('RP_MEASURE') == 'DWELLINGS' and all(d.get(x) == y for x, y in k.items()) and seul(o, keep):
                return v(o)
        return None
    rp = logv(a, OCS='DW_MAIN')
    D['annee_rp'] = a
    if rp:
        D['proprio_pct'] = round(100 * (logv(a, OCS='DW_MAIN', TSH='100') or 0) / rp)
        D['locataires_pct'] = round(100 * (logv(a, OCS='DW_MAIN', TSH='200') or 0) / rp)
        D['maisons_pct'] = round(100 * (logv(a, OCS='DW_MAIN', TDW='1') or 0) / rp)
        D['grands_logements_pct'] = round(100 * (logv(a, OCS='DW_MAIN', NOR='R_GE5') or 0) / rp)
        recent = logv(a, OCS='DW_MAIN', BUILD_END='Y2006TAAAA')
        D['recent_pct'] = round(100 * recent / rp) if recent else None
    tot, vac = logv(a, OCS='_T'), logv(a, OCS='DW_VAC')
    if tot and vac is not None:
        D['vacance_pct'] = round(100 * vac / tot, 1)
    if ans[0] != a:
        t0, v0 = logv(ans[0], OCS='_T'), logv(ans[0], OCS='DW_VAC')
        if t0 and v0 is not None:
            D['vacance_pct_ancien'] = round(100 * v0 / t0, 1); D['annee_rp_ancien'] = ans[0]

    # population et âge
    def P(an, age):
        for o in pop:
            d = o['dimensions']
            if d.get('TIME_PERIOD') == an and d.get('SEX') == '_T' and d.get('AGE') == age:
                return v(o)
        return None
    ap = sorted({o['dimensions']['TIME_PERIOD'] for o in pop}) or ['']
    bandes = [('Y_LT15', 7.5), ('Y15T24', 19.5), ('Y25T39', 32), ('Y40T54', 47), ('Y55T64', 59.5), ('Y65T79', 72), ('Y_GE80', 86)]
    s = n = 0
    for b, m in bandes:
        x = P(ap[-1], b) or 0; s += x * m; n += x
    if n:
        D['age_moyen'] = round(s / n)
    p0, p1 = P(ap[0], '_T'), P(ap[-1], '_T')
    if p0 and p1 and ap[0] != ap[-1]:
        D['evol_pop_pct'] = round(100 * (p1 - p0) / p0); D['pop_ancienne'] = round(p0); D['annee_pop_ancienne'] = ap[0]

    # CSP (actifs : PCS 1 à 6)
    r = {}
    aps = max([o['dimensions']['TIME_PERIOD'] for o in pcs] or [''])
    for o in pcs:
        d = o['dimensions']
        if d.get('TIME_PERIOD') == aps and d.get('SEX') == '_T' and d.get('AGE') == 'Y_GE15':
            r[d['PCS']] = v(o) or 0
    act = sum(r.get(str(i), 0) for i in range(1, 7))
    if act:
        D['csp'] = {k: round(100 * r.get(c, 0) / act) for k, c in [('agriculteurs', '1'), ('artisans', '2'), ('cadres', '3'), ('intermediaires', '4'), ('employes', '5'), ('ouvriers', '6')]}

    # revenus
    for o in fil:
        if o['dimensions'].get('FILOSOFI_MEASURE') == 'MED_SL' and v(o):
            D['revenu_median_mois'] = round(v(o) / 12 / 10) * 10; D['annee_filosofi'] = o['dimensions'].get('TIME_PERIOD')

    # équipements (lignes de total uniquement pour les sous-domaines)
    ab = max([o['dimensions'].get('TIME_PERIOD', '') for o in bpe] or [''])
    def B(**k):
        tot = 0
        for o in bpe:
            d = o['dimensions']
            if d.get('TIME_PERIOD') == ab and all(d.get(x) == y for x, y in k.items()):
                tot += v(o) or 0
        return round(tot)
    D['annee_bpe'] = ab
    D['ecoles'] = B(FACILITY_SDOM='C1', FACILITY_TYPE='_T')
    D['colleges'] = B(FACILITY_SDOM='C2', FACILITY_TYPE='_T')
    D['lycees'] = B(FACILITY_SDOM='C3', FACILITY_TYPE='_T')
    D['generalistes'] = B(FACILITY_TYPE='D265')
    D['pharmacies'] = B(FACILITY_TYPE='D307')
    D['loisirs'] = B(FACILITY_DOM='F', FACILITY_SDOM='_T', FACILITY_TYPE='_T')
    D['commerces'] = B(FACILITY_DOM='B', FACILITY_SDOM='_T', FACILITY_TYPE='_T')
    D['commerces_alim'] = B(FACILITY_SDOM='B2', FACILITY_TYPE='_T')

    D.update(f_dvf.result() or {})
    D.update(f_dpe.result() or {})
    return D


def dvf(insee, fournies=None):
    an = datetime.date.today().year
    u = f'https://apidf-preprod.cerema.fr/dvf_opendata/mutations/?code_insee={insee}&anneemut_min={an - 3}&page_size=500'
    res = list(fournies or [])
    if res:
        u = None
    try:
        while u:
            j = get(u, 90); res += j['results']; u = j.get('next')
    except Exception as e:
        if not res:
            return {'dvf_erreur': repr(e)[:200]}
    ventes = [m for m in res if m.get('libnatmut') == 'Vente' and m.get('libtypbien') == 'UNE MAISON' and float(m.get('sbati') or 0) > 20 and float(m.get('valeurfonc') or 0) > 10000]
    if not ventes:
        return {'dvf_erreur': f'aucune vente de maison ({len(res)} mutations)'}
    annees = sorted({m['anneemut'] for m in ventes})
    # dernière année complète disposant d'au moins 5 ventes
    choix = None
    for y in reversed(annees):
        if len([m for m in ventes if m['anneemut'] == y]) >= 5 and any(m['datemut'] >= f'{y}-11-01' for m in res):
            choix = y; break
    if choix is None:
        return {'dvf_erreur': 'pas assez de ventes récentes'}
    sel = [m for m in ventes if m['anneemut'] == choix]
    prec = [m for m in ventes if m['anneemut'] == choix - 1]
    m2 = lambda L: mediane([float(m['valeurfonc']) / float(m['sbati']) for m in L])
    out = {'annee_dvf': choix, 'ventes_maisons': len(sel), 'prix_m2_maison': round(m2(sel) / 10) * 10,
           'prix_maison_median': round(mediane([float(m['valeurfonc']) for m in sel]) / 100) * 100,
           'surface_maison_mediane': round(mediane([float(m['sbati']) for m in sel])),
           'terrain_median': round(mediane([float(m['sterr']) for m in sel if float(m.get('sterr') or 0) > 0]) or 0)}
    if len(prec) >= 5:
        out['prix_m2_maison_prec'] = round(m2(prec) / 10) * 10
    return out


def dpe(insee):
    try:
        j = get('https://data.ademe.fr/data-fair/api/v1/datasets/dpe03existant/values_agg?field=etiquette_dpe&qs=code_insee_ban:' + insee)
        c = {a['value']: a['total'] for a in j.get('aggs', [])}
        tot = sum(c.values())
        if tot >= 30:
            return {'dpe_total': tot, 'dpe_fg_pct': round(100 * (c.get('F', 0) + c.get('G', 0)) / tot), 'dpe_abc_pct': round(100 * (c.get('A', 0) + c.get('B', 0) + c.get('C', 0)) / tot)}
    except Exception:
        pass
    return {}
