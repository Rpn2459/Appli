# Service de rendu des cartes communes – Guy Hoquet Saint-Omer
import base64, json, os, traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import donnees, rendu

JETON = os.environ.get('JETON', '')


class H(BaseHTTPRequestHandler):
    def _rep(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode('utf8')
        self.send_response(code); self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith('/sante'):
            return self._rep(200, {'ok': True})
        self._rep(404, {'erreur': 'introuvable'})

    def do_POST(self):
        if JETON and self.headers.get('X-Jeton') != JETON:
            return self._rep(401, {'erreur': 'jeton invalide'})
        try:
            n = int(self.headers.get('Content-Length') or 0)
            q = json.loads(self.rfile.read(n) or b'{}')
            D = donnees.collecter(q.get('commune') or q.get('code_insee'))
            imgs = [rendu.visuel_portrait(D)]
            if D.get('prix_m2_maison'):
                imgs.append(rendu.visuel_immo(D))
            info = {k: v for k, v in D.items() if k != 'geo'}
            self._rep(200, {'commune': D['nom'], 'insee': D['insee'], 'donnees': info,
                            'images': [base64.b64encode(i).decode() for i in imgs]})
        except Exception as e:
            traceback.print_exc()
            self._rep(500, {'erreur': str(e)})

    def log_message(self, *a):
        pass


if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', int(os.environ.get('PORT', '8090'))), H).serve_forever()
