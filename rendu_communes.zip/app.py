# Service de rendu des cartes communes – Guy Hoquet Saint-Omer
# POST /carte {"commune": "Arques"}  (réservé au réseau interne Docker)
# GET  /images/<fichier>.png         (public, pour Facebook et le mail de validation)
import base64, ipaddress, json, os, re, time, traceback, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import donnees, rendu

DOSSIER = os.environ.get('DOSSIER', '/app/out')
BASE = os.environ.get('BASE_URL', 'https://cartes.srv1761873.hstgr.cloud')
os.makedirs(DOSSIER, exist_ok=True)


def interne(ip):
    try:
        a = ipaddress.ip_address(ip)
        return a.is_private or a.is_loopback
    except ValueError:
        return False


def menage():
    lim = time.time() - 30 * 86400
    for f in os.listdir(DOSSIER):
        p = os.path.join(DOSSIER, f)
        if os.path.getmtime(p) < lim:
            os.remove(p)


class H(BaseHTTPRequestHandler):
    def _rep(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode('utf8')
        self.send_response(code); self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith('/sante'):
            return self._rep(200, {'ok': True})
        m = re.fullmatch(r'/images/([a-z0-9_\-]+\.png)', self.path.split('?')[0])
        if m and os.path.exists(os.path.join(DOSSIER, m.group(1))):
            b = open(os.path.join(DOSSIER, m.group(1)), 'rb').read()
            self.send_response(200); self.send_header('Content-Type', 'image/png')
            self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b); return
        self._rep(404, {'erreur': 'introuvable'})

    def do_POST(self):
        # derrière Traefik, l'appel public arrive avec X-Forwarded-For : on le refuse
        if self.headers.get('X-Forwarded-For') or not interne(self.client_address[0]):
            return self._rep(403, {'erreur': 'accès réservé'})
        try:
            n = int(self.headers.get('Content-Length') or 0)
            q = json.loads(self.rfile.read(n) or b'{}')
            D = donnees.collecter(q.get('commune') or q.get('code_insee'))
            imgs = [('vivre', rendu.visuel_portrait(D))]
            if D.get('prix_m2_maison'):
                imgs.append(('immobilier', rendu.visuel_immo(D)))
            menage()
            cle = D['insee'] + '-' + uuid.uuid4().hex[:8]
            urls, b64 = [], []
            for nom, png in imgs:
                fic = f'{cle}-{nom}.png'
                open(os.path.join(DOSSIER, fic), 'wb').write(png)
                urls.append(f'{BASE}/images/{fic}')
                if q.get('base64'):
                    b64.append(base64.b64encode(png).decode())
            info = {k: v for k, v in D.items() if k != 'geo'}
            out = {'commune': D['nom'], 'insee': D['insee'], 'donnees': info, 'images': urls}
            if b64:
                out['images_base64'] = b64
            self._rep(200, out)
        except Exception as e:
            traceback.print_exc()
            self._rep(500, {'erreur': str(e)})

    def log_message(self, *a):
        pass


if __name__ == '__main__':
    print('Service cartes communes prêt', flush=True)
    ThreadingHTTPServer(('0.0.0.0', int(os.environ.get('PORT', '8090'))), H).serve_forever()
