# Rendu des deux visuels "Vivre à" / "L'immobilier à" (1080 x 1350, format portrait 4:5)
import io, math, os
from PIL import Image, ImageDraw, ImageFont

ICI = os.path.dirname(os.path.abspath(__file__))
NAVY = (15, 13, 48); BLUE = (29, 166, 232); FILL = (147, 218, 237); LIGHT = (190, 233, 245)
WHITE = (255, 255, 255); GREY = (105, 110, 130); BORD = (214, 228, 238); PALE = (232, 246, 252)
S = 2; W, H = 1080, 1350
PIED = "Guy Hoquet Saint-Omer  ·  8 rue de l'Écusserie, Saint-Omer"


def f(nom, taille):
    return ImageFont.truetype(os.path.join(ICI, nom), int(taille * S))


def nb(x, dec=0):
    if x is None:
        return '–'
    s = f'{x:,.{dec}f}'.replace(',', ' ').replace('.', ',')
    return s


class Toile:
    def __init__(self):
        self.img = Image.new('RGBA', (W * S, H * S), WHITE)
        self.d = ImageDraw.Draw(self.img)

    def fit(self, t, n, s, mw):
        while s > 10 and self.d.textlength(t, font=f(n, s)) / S > mw:
            s -= 1
        return f(n, s)

    def wrap(self, t, n, s, mw):
        mots, lignes, cur = t.split(), [], ''
        for m in mots:
            test = (cur + ' ' + m).strip()
            if self.d.textlength(test, font=f(n, s)) / S > mw and cur:
                lignes.append(cur); cur = m
            else:
                cur = test
        lignes.append(cur)
        return lignes

    def coller(self, im, x, y):
        self.img.paste(im, (int(x * S), int(y * S)), im)
        self.d = ImageDraw.Draw(self.img)

    def bandeau(self, sur_titre, nom, sous_titre):
        d = self.d
        d.rectangle([0, 0, W * S, 235 * S], fill=NAVY)
        logo = Image.open(os.path.join(ICI, 'logo_gh_blanc.png'))
        lw = 200; logo = logo.resize((lw * S, int(logo.height * lw / logo.width) * S), Image.LANCZOS)
        self.coller(logo, W - lw - 55, 40); d = self.d
        d.text((60 * S, 62 * S), sur_titre, font=f('Poppins-Bold.ttf', 34), fill=BLUE, anchor='lm')
        d.text((56 * S, 138 * S), nom.upper(), font=self.fit(nom.upper(), 'Poppins-Bold.ttf', 86, 720), fill=WHITE, anchor='lm')
        d.text((60 * S, 200 * S), sous_titre, font=f('Poppins-Regular.ttf', 26), fill=LIGHT, anchor='lm')

    def pied(self, sources, accroche=None):
        d = self.d
        if accroche:
            d.text((W / 2 * S, 1218 * S), accroche, font=self.fit(accroche, 'Poppins-Bold.ttf', 30, 980), fill=NAVY, anchor='mm')
        d.text((W / 2 * S, (1268 if accroche else 1278) * S), sources, font=self.fit(sources, 'Poppins-Regular.ttf', 14, 1000), fill=GREY, anchor='mm')
        d.rectangle([0, 1300 * S, W * S, H * S], fill=NAVY)
        d.text((W / 2 * S, 1325 * S), PIED, font=f('Poppins-Medium.ttf', 20), fill=WHITE, anchor='mm')

    def png(self):
        b = io.BytesIO()
        self.img.resize((W, H), Image.LANCZOS).convert('RGB').save(b, 'PNG', optimize=True)
        return b.getvalue()


def dedans(px, py, poly):
    c = False; n = len(poly)
    for i in range(n):
        (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % n]
        if (y1 > py) != (y2 > py) and px < (x2 - x1) * (py - y1) / (y2 - y1) + x1:
            c = not c
    return c


def carte(T, D):
    CX, CY, R = 540, 465, 205
    k = R / 200 * 0.86
    layer = Image.new('RGBA', T.img.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(layer)
    ld.ellipse([(CX - R) * S, (CY - R) * S, (CX + R) * S, (CY + R) * S], fill=FILL)
    P = lambda p: ((CX + p[0] * k) * S, (CY + p[1] * k) * S)
    cible = next(c for c in D['geo'] if c['code'] == D['insee'])
    for c in D['geo']:
        if c is not cible:
            ld.polygon([P(p) for p in c['pts']], fill=LIGHT, outline=WHITE, width=3 * S)
    ld.polygon([P(p) for p in cible['pts']], fill=WHITE, outline=BLUE, width=5 * S)
    fl = f('Poppins-Medium.ttf', 14)
    cib = [(CX + p[0] * k, CY + p[1] * k) for p in cible['pts']]
    places = []
    for c in sorted(D['geo'], key=lambda c: -len(c['pts'])):
        if c is cible:
            continue
        own = [(CX + p[0] * k, CY + p[1] * k) for p in c['pts']]
        vis = [q for q in own if math.hypot(q[0] - CX, q[1] - CY) < R * 0.8]
        if len(vis) < 5:
            continue
        x = sum(q[0] for q in vis) / len(vis); y = sum(q[1] for q in vis) / len(vis)
        w0 = ld.textlength(c['nom'], font=fl) / S / 2
        a = math.atan2(y - CY, x - CX)
        for step in range(0, 120, 4):
            xx, yy = x + math.cos(a) * step, y + math.sin(a) * step
            coins = [(xx - w0, yy), (xx + w0, yy), (xx, yy - 8), (xx, yy + 8)]
            if all(math.hypot(px - CX, py - CY) < R - 10 and not dedans(px, py, cib) and dedans(px, py, own) for px, py in coins) \
                    and not (abs(xx - CX) < 110 and abs(yy - CY) < 55) \
                    and all(abs(xx - ox) > (w0 + ow + 6) or abs(yy - oy) > 20 for ox, oy, ow in places):
                ld.text((xx * S, yy * S), c['nom'], font=fl, fill=GREY, anchor='mm')
                places.append((xx, yy, w0)); break
    mask = Image.new('L', T.img.size, 0)
    ImageDraw.Draw(mask).ellipse([(CX - R) * S, (CY - R) * S, (CX + R) * S, (CY + R) * S], fill=255)
    T.img.paste(layer, (0, 0), mask); T.d = ImageDraw.Draw(T.img); d = T.d
    d.ellipse([(CX - R - 4) * S, (CY - R - 4) * S, (CX + R + 4) * S, (CY + R + 4) * S], outline=NAVY, width=8 * S)
    px, py = CX, CY - 24
    d.ellipse([(px - 18) * S, (py - 18) * S, (px + 18) * S, (py + 18) * S], fill=BLUE)
    d.polygon([((px - 15) * S, (py + 9) * S), ((px + 15) * S, (py + 9) * S), (px * S, (py + 36) * S)], fill=BLUE)
    d.ellipse([(px - 7) * S, (py - 7) * S, (px + 7) * S, (py + 7) * S], fill=WHITE)
    nom = D['nom'].upper()
    d.text((CX * S, (CY + 38) * S), nom, font=T.fit(nom, 'Poppins-Bold.ttf', 30, 330), fill=BLUE, anchor='mm', stroke_width=5 * S, stroke_fill=WHITE)


def tuiles_portrait(D):
    t = []
    t.append(('habitants', 'HABITANTS', nb(D.get('population')), 'habitants', 'population légale'))
    if D.get('proprio_pct') is not None:
        t.append(('proprio', 'PROPRIÉTAIRES / LOCATAIRES', f"{D['proprio_pct']} %", 'propriétaires', f"{D['locataires_pct']} % de locataires"))
    ec, co, ly = D.get('ecoles', 0), D.get('colleges', 0), D.get('lycees', 0)
    det = ' et '.join(x for x in [f"{co} collège{'s' if co > 1 else ''}" if co else '', f"{ly} lycée{'s' if ly > 1 else ''}" if ly else ''] if x)
    t.append(('education', 'ÉDUCATION', str(ec), 'école' + ('s' if ec > 1 else ''), ('et ' + det) if det else 'écoles maternelles et élémentaires'))
    if D.get('revenu_median_mois'):
        t.append(('revenus', 'REVENU MÉDIAN', nb(D['revenu_median_mois']) + ' €', '/mois', 'niveau de vie médian par personne'))
    else:
        t.append(('revenus', 'MAISONS', f"{D.get('maisons_pct', '–')} %", 'de maisons', 'parmi les résidences principales'))
    g, ph = D.get('generalistes', 0), D.get('pharmacies', 0)
    if g:
        t.append(('sante', 'SANTÉ', str(g), 'médecin' + ('s' if g > 1 else '') + ' généraliste' + ('s' if g > 1 else ''), f"et {ph} pharmacie{'s' if ph > 1 else ''}" if ph else 'sur la commune'))
    else:
        t.append(('sante', 'SANTÉ', str(ph), 'pharmacie' + ('s' if ph > 1 else ''), 'sur la commune'))
    t.append(('age', 'ÂGE MOYEN', str(D.get('age_moyen', '–')), 'ans', 'des habitants'))
    t.append(('loisirs', 'LOISIRS', str(D.get('loisirs', 0)), 'équipement' + ('s' if D.get('loisirs', 0) > 1 else ''), 'sportifs et culturels'))
    cm, al = D.get('commerces', 0), D.get('commerces_alim', 0)
    t.append(('commerces', 'COMMERCES', str(cm), 'commerce' + ('s' if cm > 1 else ''), f"dont {al} alimentaire{'s' if al > 1 else ''}" if al else 'sur la commune'))
    return t


def visuel_portrait(D):
    T = Toile()
    T.bandeau('VIVRE À', D['nom'], 'Le portrait de votre commune en chiffres')
    carte(T, D)
    TW, TH = 465, 118
    for i, (ic, titre, val, unite, detail) in enumerate(tuiles_portrait(D)[:8]):
        x0 = 55 + (i % 2) * (TW + 40); y0 = 715 + (i // 2) * (TH + 18); d = T.d
        d.rounded_rectangle([x0 * S, y0 * S, (x0 + TW) * S, (y0 + TH) * S], radius=18 * S, fill=WHITE, outline=BORD, width=2 * S)
        im = Image.open(os.path.join(ICI, f'ic_{ic}.png')).convert('RGBA').resize((78 * S, 78 * S), Image.LANCZOS)
        T.coller(im, x0 + 18, y0 + 20); d = T.d
        tx = x0 + 115; fp = f('Poppins-Bold.ttf', 15); lw = d.textlength(titre, font=fp) / S
        d.rounded_rectangle([tx * S, (y0 + 14) * S, (tx + lw + 24) * S, (y0 + 40) * S], radius=13 * S, fill=NAVY)
        d.text(((tx + 12) * S, (y0 + 27.5) * S), titre, font=fp, fill=WHITE, anchor='lm')
        fb = T.fit(val, 'Poppins-Bold.ttf', 38, 200); vw = d.textlength(val, font=fb) / S
        d.text((tx * S, (y0 + 70) * S), val, font=fb, fill=BLUE, anchor='lm')
        gap = 0 if unite.startswith('/') else 9
        d.text(((tx + vw + gap) * S, (y0 + 72) * S), unite, font=T.fit(unite, 'Poppins-Regular.ttf', 26, TW - 130 - vw - gap), fill=NAVY, anchor='lm')
        d.text((tx * S, (y0 + 101) * S), detail, font=T.fit(detail, 'Poppins-Regular.ttf', 18, TW - 130), fill=GREY, anchor='lm')
    T.pied(f"Sources : INSEE (recensement {D.get('annee_rp')}, Filosofi {D.get('annee_filosofi', '')}, base permanente des équipements {D.get('annee_bpe')}) – contours : geo.api.gouv.fr")
    return T.png()


def tuiles_immo(D):
    t = []
    if D.get('dpe_fg_pct') is not None:
        t.append(('ÉNERGIE (DPE)', f"{D['dpe_fg_pct']} %", 'classés F ou G', f"des logements diagnostiqués (sur {nb(D['dpe_total'])} DPE), interdits à la location à terme"))
    if D.get('vacance_pct') is not None:
        det = f"contre {nb(D['vacance_pct_ancien'], 1)} % en {D['annee_rp_ancien']}" if D.get('vacance_pct_ancien') is not None else 'part des logements inoccupés'
        t.append(('LOGEMENTS VACANTS', f"{nb(D['vacance_pct'], 1)} %", 'du parc', det))
    if D.get('terrain_median'):
        t.append(('TERRAIN', f"{nb(D['terrain_median'])} m²", 'de terrain médian', f"pour les maisons vendues en {D['annee_dvf']} à {D['nom']}"))
    if D.get('grands_logements_pct') is not None:
        t.append(('GRANDS LOGEMENTS', f"{D['grands_logements_pct']} %", 'de 5 pièces ou plus', 'parmi les résidences principales'))
    if D.get('recent_pct'):
        t.append(('PARC RÉCENT', f"{D['recent_pct']} %", 'des résidences', 'principales construites depuis 2006'))
    if D.get('csp'):
        c = D['csp']
        lib = {'ouvriers': "d'ouvriers", 'employes': "d'employés", 'intermediaires': 'de prof. intermédiaires', 'cadres': 'de cadres', 'artisans': "d'artisans-commerçants", 'agriculteurs': "d'agriculteurs"}
        ordre = sorted(c, key=lambda k: -c[k])
        reste = ', '.join(f"{c[k]} % {lib[k]}" for k in ordre[1:4])
        t.append(('CATÉGORIES SOCIO-PRO', f"{c[ordre[0]]} %", lib[ordre[0]], reste + f" (actifs {D.get('annee_rp')})"))
    if D.get('maisons_pct') is not None:
        t.append(('MAISONS', f"{D['maisons_pct']} %", 'de maisons', 'parmi les résidences principales'))
    return t[:6]


def visuel_immo(D):
    T = Toile()
    T.bandeau("L'IMMOBILIER À", D['nom'], "Les chiffres que l'on ne trouve pas sur les annonces")
    d = T.d; y0 = 275
    d.rounded_rectangle([55 * S, y0 * S, (W - 55) * S, (y0 + 250) * S], radius=24 * S, fill=PALE)
    titre = f"PRIX MÉDIAN DES MAISONS EN {D['annee_dvf']}"
    fp = f('Poppins-Bold.ttf', 17)
    d.rounded_rectangle([90 * S, (y0 + 28) * S, (90 + d.textlength(titre, font=fp) / S + 28) * S, (y0 + 58) * S], radius=15 * S, fill=NAVY)
    d.text((104 * S, (y0 + 43) * S), titre, font=fp, fill=WHITE, anchor='lm')
    val = nb(D['prix_m2_maison']) + ' €'; fb = f('Poppins-Bold.ttf', 92)
    d.text((88 * S, (y0 + 125) * S), val, font=fb, fill=BLUE, anchor='lm')
    vw = d.textlength(val, font=fb) / S
    d.text(((88 + vw + 12) * S, (y0 + 140) * S), '/m²', font=f('Poppins-Medium.ttf', 36), fill=NAVY, anchor='lm')
    l1 = f"{D['ventes_maisons']} maisons vendues en {D['annee_dvf']} · prix médian {nb(D['prix_maison_median'])} € pour {D['surface_maison_mediane']} m²"
    lignes = [l1]
    if D.get('prix_m2_maison_prec'):
        e = (D['prix_m2_maison'] - D['prix_m2_maison_prec']) / D['prix_m2_maison_prec'] * 100
        tend = 'Stable sur un an' if abs(e) < 2 else (f'En hausse de {round(e)} % sur un an' if e > 0 else f'En baisse de {round(-e)} % sur un an')
        lignes.append(f"{tend} ({nb(D['prix_m2_maison_prec'])} €/m² en {D['annee_dvf'] - 1})")
    for i, l in enumerate(lignes):
        d.text((90 * S, (y0 + 195 + i * 30) * S), l, font=T.fit(l, 'Poppins-Regular.ttf', 22, 880), fill=GREY, anchor='lm')
    TW, TH = 465, 190
    for i, (titre, val, unite, detail) in enumerate(tuiles_immo(D)):
        x0 = 55 + (i % 2) * (TW + 40); y = 560 + (i // 2) * (TH + 22)
        d.rounded_rectangle([x0 * S, y * S, (x0 + TW) * S, (y + TH) * S], radius=20 * S, fill=WHITE, outline=BORD, width=2 * S)
        fp = f('Poppins-Bold.ttf', 15); lw = d.textlength(titre, font=fp) / S
        d.rounded_rectangle([(x0 + 25) * S, (y + 22) * S, (x0 + 25 + lw + 24) * S, (y + 48) * S], radius=13 * S, fill=NAVY)
        d.text(((x0 + 37) * S, (y + 35.5) * S), titre, font=fp, fill=WHITE, anchor='lm')
        fv = T.fit(val, 'Poppins-Bold.ttf', 50, 240); d.text(((x0 + 25) * S, (y + 90) * S), val, font=fv, fill=BLUE, anchor='lm')
        vw = d.textlength(val, font=fv) / S
        d.text(((x0 + 25 + vw + 12) * S, (y + 95) * S), unite, font=T.fit(unite, 'Poppins-Medium.ttf', 22, TW - 60 - vw), fill=NAVY, anchor='lm')
        for j, l in enumerate(T.wrap(detail, 'Poppins-Regular.ttf', 19, TW - 50)[:2]):
            d.text(((x0 + 25) * S, (y + 137 + j * 26) * S), l, font=f('Poppins-Regular.ttf', 19), fill=GREY, anchor='lm')
    T.pied('Sources : DVF (Cerema), ADEME (DPE), INSEE (recensements)', f"Combien vaut votre bien à {D['nom']} ? Estimation offerte en agence.")
    return T.png()
